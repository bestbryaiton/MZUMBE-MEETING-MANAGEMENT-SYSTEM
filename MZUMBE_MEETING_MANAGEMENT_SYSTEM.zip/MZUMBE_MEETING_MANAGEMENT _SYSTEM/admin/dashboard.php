<?php
require_once("../config/database.php");
require_once("session.php");

/* TOTAL USERS */
$users = $conn->query("SELECT COUNT(*) as total FROM users")
              ->fetch()['total'];

/* TOTAL TICKETS */
$tickets = $conn->query("SELECT COUNT(*) as total FROM meeting_tickets")
                ->fetch()['total'];

/* TOTAL STUDENTS */
$students = $conn->query("SELECT COUNT(*) as total FROM students")
                 ->fetch()['total'];

/* TOTAL STAFF */
$staff = $conn->query("SELECT COUNT(*) as total FROM staff")
              ->fetch()['total'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
            gap:20px;
        }

        .card-box {
            background:white;
            padding:20px;
            border-radius:10px;
            text-align:center;
            box-shadow:0 2px 10px rgba(0,0,0,0.1);
        }

        .card-box h1 {
            color:#003366;
            font-size:35px;
        }
    </style>
</head>

<body>

<div class="navbar">
    <div class="container">

        <div class="logo">
            <img src="../assets/images/mzumbe-logo.png">
            <h2>Admin Panel</h2>
        </div>

        <a href="logout.php" class="btn btn-danger">Logout</a>

    </div>
</div>

<div class="container mt-3">

    <div class="card">

        <h2>Welcome Admin, <?php echo $_SESSION['admin_name']; ?> 👋</h2>

        <hr>

        <div class="grid">

            <div class="card-box">
                <h2>Users</h2>
                <h1><?php echo $users; ?></h1>
            </div>

            <div class="card-box">
                <h2>Tickets</h2>
                <h1><?php echo $tickets; ?></h1>
            </div>

            <div class="card-box">
                <h2>Students</h2>
                <h1><?php echo $students; ?></h1>
            </div>

            <div class="card-box">
                <h2>Staff</h2>
                <h1><?php echo $staff; ?></h1>
            </div>

        </div>

        <hr>

        <a href="tickets.php" class="btn btn-primary">View All Tickets</a>
        <a href="users.php" class="btn btn-primary">View Users</a>

    </div>

</div>

</body>
</html>