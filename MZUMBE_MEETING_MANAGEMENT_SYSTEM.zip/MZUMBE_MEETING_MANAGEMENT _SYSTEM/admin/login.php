<?php
require_once("../config/database.php");
session_start();

$message = "";

if(isset($_POST['login']))
{
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM admins WHERE email=?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if($admin)
    {
        if(password_verify($password, $admin['password']))
        {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];

            header("Location: dashboard.php");
            exit();
        }
        else
        {
            $message = "Wrong password!";
        }
    }
    else
    {
        $message = "Admin not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<div class="auth-page">

    <div class="auth-card">

        <div class="auth-logo">
            <img src="../assets/images/mzumbe-logo.png">
            <h2>Admin Panel Login</h2>
        </div>

        <?php if($message != ""): ?>
            <div class="alert alert-danger">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type="submit" name="login" class="btn btn-primary">
                Login
            </button>

        </form>

    </div>

</div>

</body>
</html>