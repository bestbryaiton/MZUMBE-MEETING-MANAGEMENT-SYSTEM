<?php
require_once("../config/database.php");
session_start();

$message = "";
$type = "";

if(isset($_POST['login']))
{
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user)
    {
        if(password_verify($password, $user['password']))
        {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['user_type'] = $user['user_type'];
            $_SESSION['reg_staff_no'] = $user['reg_staff_no'];

            header("Location: ../dashboard.php");
            exit();
        }
        else
        {
            $message = "Wrong password!";
            $type = "danger";
        }
    }
    else
    {
        $message = "User not found!";
        $type = "danger";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<div class="auth-page">

    <div class="auth-card">

        <div class="auth-logo">
            <img src="../assets/images/mzumbe-logo.png">
            <h2>Login to System</h2>
        </div>

        <?php if($message != ""): ?>
            <div class="alert alert-<?php echo $type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <button type="submit" name="login" class="btn btn-primary">
                Login
            </button>

        </form>

        <p class="mt-3 text-center">
            Don't have an account?
            <a href="register.php">Register</a>
        </p>

    </div>

</div>

</body>
</html>