<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once("../config/database.php");

$message = "";
$type = "";

if(isset($_POST['register']))
{
    $user_type = $_POST['user_type'];
    $full_name = trim($_POST['full_name']);
    $reg_staff_no = trim($_POST['reg_staff_no']);
    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    try {

        // =========================
        // CHECK IF ALREADY EXISTS
        // =========================
        $checkUser = $conn->prepare("
            SELECT * FROM users WHERE reg_staff_no = ?
        ");
        $checkUser->execute([$reg_staff_no]);

        if($checkUser->rowCount() > 0)
        {
            $message = "This user is already registered. Please login.";
            $type = "danger";
        }

        // =========================
        // VERIFY STUDENT
        // =========================
        if(empty($message) && $user_type == "Student")
        {
            $check = $conn->prepare("
                SELECT * FROM students
                WHERE reg_no=? AND status='Active'
            ");

            $check->execute([$reg_staff_no]);

            if($check->rowCount() == 0)
            {
                $message = "Student Registration Number not found.";
                $type = "danger";
            }
        }

        // =========================
        // VERIFY STAFF
        // =========================
        if(empty($message) && $user_type == "Staff")
        {
            $check = $conn->prepare("
                SELECT * FROM staff
                WHERE staff_id=? AND status='Active'
            ");

            $check->execute([$reg_staff_no]);

            if($check->rowCount() == 0)
            {
                $message = "Staff ID not found.";
                $type = "danger";
            }
        }

        // =========================
        // INSERT USER
        // =========================
        if(empty($message))
        {
            $insert = $conn->prepare("
                INSERT INTO users
                (user_type, full_name, reg_staff_no, email, password)
                VALUES(?,?,?,?,?)
            ");

            $insert->execute([
                $user_type,
                $full_name,
                $reg_staff_no,
                $email,
                $password
            ]);

            // SUCCESS MESSAGE + REDIRECT
            $message = "Registration Successful! Redirecting to login...";
            $type = "success";

            header("refresh:2;url=login.php");
        }

    } catch(PDOException $e) {
        $message = "System error: " . $e->getMessage();
        $type = "danger";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>

<div class="auth-page">

<div class="auth-card">

<div class="auth-logo">
<img src="../assets/images/mzumbe-logo.png">
<h2>Mzumbe Meeting Management System</h2>
</div>

<?php if($message != ""): ?>
<div class="alert alert-<?php echo $type; ?>">
<?php echo $message; ?>
</div>
<?php endif; ?>

<form method="POST">

<div class="form-group">
<label>User Type</label>
<select name="user_type" class="form-control" required>
<option value="">Select</option>
<option>Student</option>
<option>Staff</option>
</select>
</div>

<div class="form-group">
<label>Full Name</label>
<input type="text" name="full_name" class="form-control" required>
</div>

<div class="form-group">
<label>Registration No / Staff ID</label>
<input type="text" name="reg_staff_no" class="form-control" required>
</div>

<div class="form-group">
<label>Email</label>
<input type="email" name="email" class="form-control" required>
</div>

<div class="form-group">
<label>Password</label>
<input type="password" name="password" class="form-control" required>
</div>

<button type="submit" name="register" class="btn btn-primary">
Register
</button>

</form>

<p class="mt-3 text-center">
Already have an account?
<a href="login.php">Login</a>
</p>

</div>

</div>

</body>
</html>