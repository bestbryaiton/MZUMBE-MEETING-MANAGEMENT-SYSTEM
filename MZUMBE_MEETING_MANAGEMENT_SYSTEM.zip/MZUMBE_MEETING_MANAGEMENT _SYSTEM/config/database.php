<?php

$host = "localhost";
$dbname = "mzumbe_meeting_db";
$username = "root";
$password = "kisakyando@123";

try {
    $conn = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8",
        $username,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch(PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}
?>