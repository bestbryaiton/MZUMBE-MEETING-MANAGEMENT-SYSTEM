<?php
require_once("config/database.php");
require_once("auth/session.php");
include("lib/phpqrcode/qrlib.php");

$message = "";
$type = "";

if(isset($_POST['submit']))
{
    $user_id = $_SESSION['user_id'];
    $meeting_type = $_POST['meeting_type'];
    $meeting_date = $_POST['meeting_date'];
    $meeting_time = $_POST['meeting_time'];

    /* =========================
       VALIDATE FILE
    ========================== */
    if(!isset($_FILES['passport']) || $_FILES['passport']['error'] != 0)
    {
        $message = "Please upload a valid passport photo";
        $type = "danger";
    }
    else
    {
        $file = $_FILES['passport'];

        $allowed = ['jpg','jpeg','png'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if(!in_array($ext, $allowed))
        {
            $message = "Only JPG and PNG allowed";
            $type = "danger";
        }
        elseif($file['size'] > 500000)
        {
            $message = "Image must not exceed 500KB";
            $type = "danger";
        }
        else
        {
            /* =========================
               SAVE PASSPORT
            ========================== */

            $filename = time() . "_" . uniqid() . "." . $ext;
            $passport_path = "uploads/passports/" . $filename;

            move_uploaded_file($file['tmp_name'], $passport_path);

            /* =========================
               GENERATE TICKET NUMBER
            ========================== */

            $ticket_no = "MZM-" . date("Y") . "-" . rand(10000,99999);

            /* =========================
               QR CONTENT
            ========================== */

            $qr_text =
"MZUMBE UNIVERSITY
MEETING MANAGEMENT SYSTEM

Ticket: $ticket_no
Name: ".$_SESSION['full_name']."
ID: ".$_SESSION['reg_staff_no']."
Meeting: $meeting_type
Date: $meeting_date
Time: $meeting_time
Status: VERIFIED";

            /* =========================
               CREATE QR
            ========================== */

            $qr_file = "uploads/qrcodes/" . $ticket_no . ".png";
            QRcode::png($qr_text, $qr_file, "L", 6, 2);

            /* =========================
               INSERT INTO DB
            ========================== */

            $stmt = $conn->prepare("
                INSERT INTO meeting_tickets
                (ticket_number, user_id, meeting_type, meeting_date, meeting_time, passport_image_path, qr_code_path)
                VALUES (?,?,?,?,?,?,?)
            ");

            $stmt->execute([
                $ticket_no,
                $user_id,
                $meeting_type,
                $meeting_date,
                $meeting_time,
                $passport_path,
                $qr_file
            ]);

            $ticket_id = $conn->lastInsertId();

            /* =========================
               SUCCESS MESSAGE
            ========================== */

            $message = "Ticket generated successfully!";
            $type = "success";

            $download_link = "download_ticket.php?id=" . $ticket_id;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Ticket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="navbar">
    <div class="container">
        <div class="logo">
            <img src="assets/images/mzumbe-logo.png">
            <h2>Create Meeting Ticket</h2>
        </div>

        <a href="dashboard.php" class="btn btn-danger">Back</a>
    </div>
</div>

<div class="container mt-3">

    <div class="card">

        <?php if($message != ""): ?>
            <div class="alert alert-<?php echo $type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if(isset($download_link)): ?>
            <div class="alert alert-success">
                <a href="<?php echo $download_link; ?>" class="btn btn-primary">
                    Download Your Ticket (PNG)
                </a>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">

            <div class="form-group">
                <label>Meeting Type</label>
                <select name="meeting_type" class="form-control" required>
                    <option value="">-- Select --</option>
                    <option>Board Meeting</option>
                    <option>Workshop</option>
                    <option>Seminar</option>
                    <option>Conference</option>
                </select>
            </div>

            <div class="form-group">
                <label>Meeting Date</label>
                <input type="date" name="meeting_date" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Meeting Time</label>
                <input type="time" name="meeting_time" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Passport Photo (JPG/PNG max 500KB)</label>
                <input type="file" name="passport" class="form-control" required>
            </div>

            <button type="submit" name="submit" class="btn btn-primary">
                Generate Ticket
            </button>

        </form>

    </div>

</div>

</body>
</html>