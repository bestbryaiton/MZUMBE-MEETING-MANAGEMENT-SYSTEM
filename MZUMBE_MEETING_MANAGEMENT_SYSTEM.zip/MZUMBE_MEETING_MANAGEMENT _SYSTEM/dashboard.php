<?php
require_once("config/database.php");
require_once("auth/session.php");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="navbar">
    <div class="container">

        <div class="logo">
            <img src="assets/images/mzumbe-logo.png">
            <h2>Mzumbe Meeting System</h2>
        </div>

        <div>
            <a href="auth/logout.php" class="btn btn-danger">Logout</a>
        </div>

    </div>
</div>

<div class="container mt-3">

    <div class="card">

        <h2>Welcome, <?php echo $_SESSION['full_name']; ?></h2>

        <p><b>Role:</b> <?php echo $_SESSION['user_type']; ?></p>
        <p><b>ID:</b> <?php echo $_SESSION['reg_staff_no']; ?></p>

        <hr>

       <div style="margin-top:20px; display:flex; flex-direction:column; gap:10px;">

    <a href="create_ticket.php" class="btn btn-primary">
        ➕ Create Ticket
    </a>

    <a href="my_tickets.php" class="btn btn-primary">
        🎫 My Tickets
    </a>

</div>

    </div>

</div>

</body>
</html>