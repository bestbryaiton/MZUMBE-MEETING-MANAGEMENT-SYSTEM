-- ==========================================
-- MZUMBE MEETING MANAGEMENT SYSTEM DATABASE
-- Database: mzumbe_meeting_db
-- ==========================================

CREATE DATABASE IF NOT EXISTS mzumbe_meeting_db;
USE mzumbe_meeting_db;

-- ==========================================
-- STUDENTS TABLE
-- Used for verifying Mzumbe students
-- ==========================================

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reg_no VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    programme VARCHAR(150) NOT NULL,
    faculty VARCHAR(150),
    academic_year VARCHAR(50),
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample Student Records

INSERT INTO students
(reg_no, full_name, programme, faculty, academic_year)
VALUES
('14322020/T.24','BEST J SANGA','BSc. Information Technology and Systems','School of Computing','2024/2025'),
('14322021/T.24','John Michael','BSc. Computer Science','School of Computing','2024/2025'),
('14322022/T.24','Asha Mrema','BSc. Economics','Faculty of Economics','2024/2025');



-- ==========================================
-- STAFF TABLE
-- Used for verifying Mzumbe staff members
-- ==========================================

CREATE TABLE staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_id VARCHAR(50) NOT NULL UNIQUE,
    full_name VARCHAR(150) NOT NULL,
    department VARCHAR(150) NOT NULL,
    position VARCHAR(100),
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample Staff Records

INSERT INTO staff
(staff_id, full_name, department, position)
VALUES
('MZU001','Dr. Joseph Mrema','ICT Department','Lecturer'),
('MZU002','Neema Komba','Human Resource','HR Officer'),
('MZU003','David Mushi','Finance Department','Accountant');



-- ==========================================
-- USERS TABLE
-- Registered users of the system
-- ==========================================

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,

    user_type ENUM('Student','Staff') NOT NULL,

    full_name VARCHAR(150) NOT NULL,

    reg_staff_no VARCHAR(50) NOT NULL UNIQUE,

    email VARCHAR(150) NOT NULL UNIQUE,

    password VARCHAR(255) NOT NULL,

    passport_image VARCHAR(255),

    account_status ENUM('Pending','Verified','Blocked')
    DEFAULT 'Verified',

    last_login DATETIME NULL,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



-- ==========================================
-- MEETING TYPES TABLE
-- Admin can manage meeting categories
-- ==========================================

CREATE TABLE meeting_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    meeting_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    status ENUM('Active','Inactive') DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO meeting_types
(meeting_name, description)
VALUES
('Board Meeting','University board meetings'),
('Workshop','Training workshops'),
('Seminar','Academic seminars'),
('Conference','Conferences and symposiums'),
('Department Meeting','Departmental meetings'),
('Student Meeting','Student representative meetings');



-- ==========================================
-- MEETINGS TABLE
-- Meeting schedules
-- ==========================================

CREATE TABLE meetings (
    id INT AUTO_INCREMENT PRIMARY KEY,

    meeting_type_id INT NOT NULL,

    meeting_title VARCHAR(255) NOT NULL,

    venue VARCHAR(255) NOT NULL,

    meeting_date DATE NOT NULL,

    meeting_time TIME NOT NULL,

    organizer_name VARCHAR(150),

    description TEXT,

    status ENUM('Scheduled','Cancelled','Completed')
    DEFAULT 'Scheduled',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (meeting_type_id)
    REFERENCES meeting_types(id)
    ON DELETE CASCADE
);



-- ==========================================
-- MEETING TICKETS TABLE
-- Generated tickets
-- ==========================================

CREATE TABLE meeting_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,

    ticket_number VARCHAR(50) UNIQUE NOT NULL,

    user_id INT NOT NULL,

    meeting_id INT NOT NULL,

    passport_image_path VARCHAR(255) NOT NULL,

    qr_code_path VARCHAR(255),

    ticket_image_path VARCHAR(255),

    attendance_status ENUM('Not Attended','Attended')
    DEFAULT 'Not Attended',

    verification_status ENUM('Pending','Verified')
    DEFAULT 'Verified',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
    REFERENCES users(id)
    ON DELETE CASCADE,

    FOREIGN KEY (meeting_id)
    REFERENCES meetings(id)
    ON DELETE CASCADE
);



-- ==========================================
-- ATTENDANCE TABLE
-- QR code attendance records
-- ==========================================

CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,

    ticket_id INT NOT NULL,

    check_in_time DATETIME,

    attendance_status ENUM('Present','Absent')
    DEFAULT 'Present',

    remarks TEXT,

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (ticket_id)
    REFERENCES meeting_tickets(id)
    ON DELETE CASCADE
);



-- ==========================================
-- ADMINS TABLE
-- System administrators
-- ==========================================

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,

    full_name VARCHAR(150) NOT NULL,

    email VARCHAR(150) UNIQUE NOT NULL,

    password VARCHAR(255) NOT NULL,

    role ENUM('Super Admin','Admin')
    DEFAULT 'Admin',

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);



-- ==========================================
-- SAMPLE ADMIN ACCOUNT
-- Password: admin123
-- Hash generated using PHP password_hash()
-- ==========================================

INSERT INTO admins
(full_name,email,password,role)
VALUES
(
'System Administrator',
'admin@mzumbe.ac.tz',
'$2y$10$3Vb7L6vNQ0q4dE3W2P0Y2Oj5l5Q7jWkq7cR1zqQ6L9h2hN8T4rYpO',
'Super Admin'
);



-- ==========================================
-- SAMPLE MEETING
-- ==========================================

INSERT INTO meetings
(
meeting_type_id,
meeting_title,
venue,
meeting_date,
meeting_time,
organizer_name,
description
)
VALUES
(
2,
'ICT Security Workshop',
'Main Campus Hall',
'2026-07-15',
'09:00:00',
'ICT Department',
'Cyber Security Awareness Workshop'
);



-- ==========================================
-- END OF DATABASE
-- ==========================================