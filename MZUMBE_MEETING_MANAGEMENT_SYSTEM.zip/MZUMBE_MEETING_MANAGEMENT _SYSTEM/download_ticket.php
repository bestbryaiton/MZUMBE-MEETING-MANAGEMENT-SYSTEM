<?php
require_once("config/database.php");
require_once("auth/session.php");

error_reporting(E_ALL);
ini_set('display_errors', 1);

$ticket_id = $_GET['id'] ?? null;

if (!$ticket_id) {
    die("Invalid ticket ID.");
}

/* =========================
   GET TICKET DATA
========================= */

$stmt = $conn->prepare("
    SELECT mt.*, u.full_name, u.reg_staff_no, u.user_type
    FROM meeting_tickets mt
    JOIN users u ON mt.user_id = u.id
    WHERE mt.id = ?
");

$stmt->execute([$ticket_id]);
$ticket = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$ticket) {
    die("Ticket not found.");
}

/* =========================
   CREATE TICKET CANVAS
========================= */

$width = 800;
$height = 600;

$image = imagecreatetruecolor($width, $height);

$white = imagecolorallocate($image, 255, 255, 255);
$blue  = imagecolorallocate($image, 0, 51, 102);
$gold  = imagecolorallocate($image, 255, 215, 0);
$black = imagecolorallocate($image, 0, 0, 0);

imagefilledrectangle($image, 0, 0, $width, $height, $white);

/* HEADER */
imagefilledrectangle($image, 0, 0, $width, 80, $blue);

imagestring($image, 5, 250, 20, "MZUMBE UNIVERSITY", $white);
imagestring($image, 4, 220, 45, "MEETING MANAGEMENT SYSTEM", $gold);

/* =========================
   LOAD LOGO
========================= */

$logo_path = "assets/images/mzumbe-logo.png";

if (!file_exists($logo_path)) {
    die("Logo file not found: " . $logo_path);
}

$logo = imagecreatefrompng($logo_path);

if (!$logo) {
    die("Unable to load logo image.");
}

imagecopyresampled(
    $image,
    $logo,
    15,
    10,
    0,
    0,
    60,
    60,
    imagesx($logo),
    imagesy($logo)
);

/* =========================
   LOAD PASSPORT PHOTO
========================= */

$passport_path = $ticket['passport_image_path'];

if (!file_exists($passport_path)) {
    die("Passport image not found: " . $passport_path);
}

$extension = strtolower(pathinfo($passport_path, PATHINFO_EXTENSION));

if ($extension == "jpg" || $extension == "jpeg") {
    $passport = imagecreatefromjpeg($passport_path);
}
elseif ($extension == "png") {
    $passport = imagecreatefrompng($passport_path);
}
else {
    die("Unsupported passport image format.");
}

if (!$passport) {
    die("Failed to load passport image.");
}

imagecopyresampled(
    $image,
    $passport,
    30,
    120,
    0,
    0,
    150,
    150,
    imagesx($passport),
    imagesy($passport)
);

/* =========================
   LOAD QR CODE
========================= */

$qr_path = $ticket['qr_code_path'];

if (!file_exists($qr_path)) {
    die("QR code image not found: " . $qr_path);
}

$qr = imagecreatefrompng($qr_path);

if (!$qr) {
    die("Failed to load QR code.");
}

imagecopyresampled(
    $image,
    $qr,
    600,
    350,
    0,
    0,
    150,
    150,
    imagesx($qr),
    imagesy($qr)
);

/* =========================
   TICKET DETAILS
========================= */

$ticket_number = $ticket['ticket_number'] ?? ('MZM-' . $ticket['id']);

$y = 120;

imagestring($image, 5, 220, $y, "Ticket No: " . $ticket_number, $black);
$y += 35;

imagestring($image, 4, 220, $y, "Name: " . $ticket['full_name'], $black);
$y += 30;

imagestring($image, 4, 220, $y, "Reg/Staff No: " . $ticket['reg_staff_no'], $black);
$y += 30;

imagestring($image, 4, 220, $y, "User Type: " . $ticket['user_type'], $black);
$y += 30;

imagestring($image, 4, 220, $y, "Meeting: " . $ticket['meeting_type'], $black);
$y += 30;

imagestring($image, 4, 220, $y, "Date: " . $ticket['meeting_date'], $black);
$y += 30;

imagestring($image, 4, 220, $y, "Time: " . $ticket['meeting_time'], $black);
$y += 30;

imagestring($image, 4, 220, $y, "Status: VERIFIED", $blue);

/* FOOTER */
imagefilledrectangle($image, 0, 570, $width, 600, $blue);
imagestring(
    $image,
    3,
    250,
    580,
    "Mzumbe University Meeting Management System",
    $white
);

/* =========================
   OUTPUT PNG
========================= */

header("Content-Type: image/png");
header("Content-Disposition: attachment; filename=Mzumbe_Ticket_" . $ticket_id . ".png");

imagepng($image);

/* CLEANUP */

imagedestroy($image);

if (isset($logo)) {
    imagedestroy($logo);
}

if (isset($passport)) {
    imagedestroy($passport);
}

if (isset($qr)) {
    imagedestroy($qr);
}

exit;
?>