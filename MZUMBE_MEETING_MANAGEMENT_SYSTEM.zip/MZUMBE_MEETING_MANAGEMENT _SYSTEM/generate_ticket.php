<?php
require_once("config/database.php");
require_once("auth/session.php");
include_once __DIR__ . "/lib/phpqrcode/qrlib.php";

if(!isset($_POST['submit']))
{
    header("Location: create_ticket.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$meeting_type = $_POST['meeting_type'];
$meeting_date = $_POST['meeting_date'];
$meeting_time = $_POST['meeting_time'];

/* =========================
   VALIDATE FILE
========================= */

$file = $_FILES['passport'];

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed = ['jpg','jpeg','png'];

if(!in_array($ext, $allowed))
{
    die("Invalid file type");
}

if($file['size'] > 500000)
{
    die("File too large");
}

/* =========================
   SAVE IMAGE
========================= */

$filename = time() . "_" . uniqid() . "." . $ext;
$passport_path = "uploads/passports/" . $filename;

move_uploaded_file($file['tmp_name'], $passport_path);

/* =========================
   TICKET NUMBER
========================= */

$ticket_no = "MZM-" . date("Y") . "-" . rand(10000,99999);

/* =========================
   QR DATA
========================= */

$qr_text =
"MZUMBE UNIVERSITY
MEETING SYSTEM

Ticket: $ticket_no
Name: ".$_SESSION['full_name']."
ID: ".$_SESSION['reg_staff_no']."
Type: $meeting_type
Date: $meeting_date
Time: $meeting_time";

/* =========================
   QR GENERATION
========================= */

$qr_file = "uploads/qrcodes/" . $ticket_no . ".png";

QRcode::png($qr_text, $qr_file, QR_ECLEVEL_L, 6, 2);

/* =========================
   SAVE TO DATABASE
========================= */

$stmt = $conn->prepare("
    INSERT INTO meeting_tickets
    (ticket_number, user_id, meeting_type, meeting_date, meeting_time, passport_image_path, qr_code_path)
    VALUES (?,?,?,?,?,?,?)
");

$stmt->execute([
    $ticket_no,
    $user_id,
    $meeting_type,
    $meeting_date,
    $meeting_time,
    $passport_path,
    $qr_file
]);

$ticket_id = $conn->lastInsertId();

/* =========================
   REDIRECT TO DOWNLOAD
========================= */

header("Location: download_ticket.php?id=" . $ticket_id);
exit();
?>