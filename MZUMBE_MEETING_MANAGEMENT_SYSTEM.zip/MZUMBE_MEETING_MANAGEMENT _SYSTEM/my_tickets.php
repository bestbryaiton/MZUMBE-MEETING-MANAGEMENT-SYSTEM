<?php
require_once("config/database.php");
require_once("auth/session.php");

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("
    SELECT * FROM meeting_tickets
    WHERE user_id = ?
    ORDER BY created_at DESC
");

$stmt->execute([$user_id]);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Tickets</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<div class="navbar">
    <div class="container">
        <div class="logo">
            <img src="assets/images/mzumbe-logo.png">
            <h2>My Meeting Tickets</h2>
        </div>

        <a href="dashboard.php" class="btn btn-danger">Back</a>
    </div>
</div>

<div class="container mt-3">

    <div class="card">

        <h3>Your Generated Tickets</h3>
        <hr>

        <?php if(count($tickets) == 0): ?>
            <p>No tickets found.</p>
        <?php else: ?>

        <table width="100%" border="1" cellpadding="10" style="border-collapse:collapse;">
            <tr style="background:#003366;color:white;">
                <th>Ticket No</th>
                <th>Meeting Type</th>
                <th>Date</th>
                <th>Time</th>
                <th>Action</th>
            </tr>

            <?php foreach($tickets as $t): ?>
            <tr>
                <td><?php echo $t['ticket_number']; ?></td>
                <td><?php echo $t['meeting_type']; ?></td>
                <td><?php echo $t['meeting_date']; ?></td>
                <td><?php echo $t['meeting_time']; ?></td>
                <td>
                    <a class="btn btn-primary"
                       href="download_ticket.php?id=<?php echo $t['id']; ?>">
                        Download
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>

        </table>

        <?php endif; ?>

    </div>

</div>

</body>
</html>